export const url = process.env.AUTH_URL || 'students-ms';
export const port = process.env.AUTH_PORT || '4000';
export const entryPoint = process.env.AUTH_ENTRY || 'ldap';